# AWS Receipt Processing Serverless Pipeline

Author: nouran ali
Status: Draft
Category: PRD
Last edited time: June 22, 2025 1:31 PM

## 🎯 Overview

This project automates the extraction and analysis of receipt data using AWS serverless services. Users upload receipts (images/PDFs) to an S3 bucket, which triggers a Lambda function to process the data via Amazon Textract. Key details (total amount, date, vendor, etc.) are stored in DynamoDB, and an SNS notification is sent via email. AWS Glue and Athena enable SQL-based querying for analytics.

## 🔧 Technical Details

### **1. File Upload to S3**

- Users upload receipts (JPEG/PNG/PDF) to an **S3 bucket**.
- **S3 Event Notification** triggers a Lambda function when file is uploaded

![image.png](image.png)

### **2. Adding IAM role to connect all the services to communicate together.**

![image.png](image%201.png)

### **3.Text Extraction (Lambda + Textract)**

- **Lambda Function**:
    - Invokes **Amazon Textract** to extract text data (total, date, vendor)
    - Parses and validates the response
    
    ![image.png](74d29e6e-acda-4e66-9b58-b794c1ced3ac.png)
    

### **4. Data Storage (DynamoDB)**

- Processed data is saved to **DynamoDB** with a schema like:

![image.png](image%202.png)

### **5. Email Alerts (SES)**

- DynamoDB Stream triggers to send email alerts via **SES**:

![image.png](image%203.png)

### **Architecture Diagram**

![image.png](image%204.png)